import React, { Component } from "react";
import QuizQuestion from "./QuizQuestion";

class Quiz extends Component {
  constructor(props) {
    super();
    this.state = { quiz_position: 1 };
  }
  render() {
    return (
      <div className="QuizQuestion">
        <QuizQuestion  {this.props.quizData.quiz_questions}/>
      </div>
    );
  }
}

export default Quiz;
