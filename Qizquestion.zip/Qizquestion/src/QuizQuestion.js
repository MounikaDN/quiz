import React, { Component } from "react";

class QuizQuestion extends Component {
  constructor(props) {
    super();
    this.state = {};
  }
  render() {
    return(
    <div>
<main>
        <section>
          <p>// instruction text goes here</p>
        </section>
        <section className="buttons">
          <ul>
            <li>{this.props.quiz_question.answer_options[0]}</li>
          </ul>
        </section>
      </main>

    </div>
    )
  }
}


export default QuizQuestion;
